#!/usr/bin/python
import sys,random,re,string,math,os.path

def f5(seq, idfun=None): 
    # order preserving
    if idfun is None:
        def idfun(x): return x
    seen = {}
    result = []
    for item in seq:
        marker = idfun(item)
        # in old Python versions:
        # if seen.has_key(marker)
        # but in new ones:
        if marker in seen: continue
        seen[marker] = 1
        result.append(item)
    return result
                
                
if len(sys.argv) == 1:
    print u'Usage: %s [file=<filename>]'.encode('latin-1') % (sys.argv[0],)
    sys.exit(0)
else:
    for argi in range(1,len(sys.argv)):
        if re.search('file=',sys.argv[argi]):
            filename = sys.argv[argi][5:]
            #print '/* Filename = %s' % filename
            
# parsing the file:
fp = file(filename, "r");

linesOfText = []

while True:
    line = fp.readline()
    if not line: break
    strt = line.find('\": \"')
    linesOfText.append(line[:strt+1])
    
#linesOfText.sort()

for i in f5(linesOfText):
    print i+": \"\","
    
    